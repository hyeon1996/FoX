from .basic_controller import BasicMAC
REGISTRY = {}


REGISTRY["basic_mac"] = BasicMAC
